﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebRepeatApp.DAL;
using WebRepeatApp.Models;
using WebRepeatApp.ViewModels;

namespace WebRepeatApp.Controllers
{
    public class CategoryController : Controller
    {
        private readonly AppDbContext _db;
        public CategoryController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index(int? id)
        {
            if (id == null) return NotFound();
            Category category = _db.Categories.Where(c => c.IsDeleted == false).FirstOrDefault();
            if (category == null) return NotFound();
            CategoryVM categoryVM = new CategoryVM
            {
                Category = category,
                Categories = _db.Categories.Where(c => c.IsDeleted == false && c.IsMain == true)
                .Include(c => c.Children).ToList()
            };
            return View(categoryVM);
        }
    }
}