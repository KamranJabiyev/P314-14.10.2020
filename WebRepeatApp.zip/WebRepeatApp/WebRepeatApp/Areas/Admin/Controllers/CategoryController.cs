﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebRepeatApp.DAL;
using WebRepeatApp.Extentions;
using WebRepeatApp.Models;

namespace WebRepeatApp.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;
        public CategoryController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }
        public IActionResult Index()
        {
            return View(_context.Categories.Where(c=>c.IsDeleted==false).ToList());
        }

        public IActionResult Create()
        {
            ViewBag.ParentCat = _context.Categories.Where(c => c.IsMain && c.IsDeleted == false).ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Category category,int? MainCtgId)
        {
            ViewBag.ParentCat = _context.Categories.Where(c => c.IsMain && c.IsDeleted == false).ToList();
            if (!ModelState.IsValid) return View();
            if (category.IsMain)
            {
                bool IsExist = _context.Categories.Where(c => c.IsMain && c.IsDeleted == false)
                    .Any(c => c.Name.ToLower() == category.Name.ToLower());
                if (IsExist)
                {
                    ModelState.AddModelError("Name", "This main category already exist!!!");
                    return View();
                }

                if (category.Photo == null)
                {
                    ModelState.AddModelError("Photo", "Please select photo for main category!!!");
                    return View();
                }

                if (!category.Photo.IsImage("image"))
                {
                    ModelState.AddModelError("Photo", "Please select image types!!!");
                    return View();
                }

                if (category.Photo.MaxLength(300))
                {
                    ModelState.AddModelError("Photo", "Image length must be max 300kb!!!");
                    return View();
                }

                string folder = Path.Combine("assets", "images");
                string fileName =await category.Photo.SaveImage(_env.WebRootPath, folder);
                category.Image = fileName;
                category.IsDeleted = false;
            }
            else
            {
                if (MainCtgId == null) return NotFound();
                Category mainCategory = _context.Categories.Include(c => c.Children).FirstOrDefault(c => c.Id == MainCtgId);
                if (mainCategory == null) return NotFound();
                Category hasCategory=mainCategory.Children.FirstOrDefault(c => c.Name.ToLower() == category.Name.ToLower());
                if (hasCategory != null)
                {
                    ModelState.AddModelError("Name", $"{mainCategory.Name} category has already {hasCategory.Name}!!!");
                    return View();
                }
                category.Parent = mainCategory;
            }
            await _context.Categories.AddAsync(category);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            Category category =await _context.Categories.FindAsync(id);
            if (category == null) return NotFound();
            return View(category);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeletePost(int? id)
        {
            if (id == null) return NotFound();
            Category category = await _context.Categories.Include(c=>c.Children).FirstOrDefaultAsync(c=>c.Id==id);
            if (category == null) return NotFound();

            //_context.Categories.Remove(category);

            //_context.Categories.Remove(category);
            //foreach (Category child in category.Children)
            //{
            //    _context.Categories.Remove(child);
            //}

            category.IsDeleted = true;
            foreach (Category child in category.Children)
            {
                child.IsDeleted = true;
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
    }
}